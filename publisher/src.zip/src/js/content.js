function injectScript(file_path, tag) {
    var node = document.getElementsByTagName(tag)[0];
    var script = document.createElement('script');
    script.setAttribute('type', 'text/javascript');
    script.setAttribute('src', file_path);
    node.appendChild(script);
}


if (document.location.href.includes("pokernow.club")) {
    injectScript(chrome.runtime.getURL('js/scripts/pokernow.js'), 'body');
} else if (document.location.href.includes("ignitioncasino.eu")) {
    injectScript(chrome.runtime.getURL('js/scripts/ignition.js'), 'body');
}


function compareHands(hand1, hand2) {
    if (!hand1 || !hand2) { return false; }

    if (hand1.value1 == hand2.value1 && hand1.suit1 == hand2.suit1) {
        if (hand1.value2 == hand2.value2 && hand1.suit2 == hand2.suit2) {
            return true;
        }
    }
    return false;
}


const values = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];

function checkRange(hand) {
    let suited = false;
    if (hand.suit1 == hand.suit2) { suited = true; }

    chrome.storage.local.get(["fold", "range"], (result) => {
        let handString = "";
        let c1 = values.indexOf(hand.value1);
        let c2 = values.indexOf(hand.value2);

        if (c1 < c2) {
            handString = `${hand.value2} ${hand.value1}`;
        } else {
            handString = `${hand.value1} ${hand.value2}`;
        }

        if (suited) {
            handString = handString + " s";
        } else {
            handString = handString + " o";
        }

        let i = result.range.indexOf(handString);
        let action = result.fold[i];

        if (action == false) {
            var sound = new Audio(chrome.runtime.getURL("/media/alert.mp3"));
            sound.volume = 0.1;
            sound.play().catch(() => {
            });

        } else {
            chrome.storage.local.get(["handsFolded"], (result) => {
                let i = result.handsFolded + 1;
                chrome.storage.local.set({"handsFolded": i});
            })
        }

        window.postMessage({type: "FROM_EXTENSION", text: action}, "*");
    });
}



var previousHand;

window.addEventListener("message", (event) => {
    if (event.source != window) {
        return;
    }

    if (event.data.type && (event.data.type == "FROM_PAGE")) {
        if (event.data.text) {
            let hand = JSON.parse(event.data.text);

            if (!compareHands(hand, previousHand)) {
                checkRange(hand);
                try {
                    chrome.runtime.sendMessage({
                        type: "HAND_DATA",
                        data: {
                            value1: hand.value1,
                            suit1: hand.suit1,
                            value2: hand.value2,
                            suit2: hand.suit2,
                            url: hand.url,
                            timestamp: Date.now()
                        }
                    }).catch(() => {
                    });
                } catch (e) {
                }
            }

            previousHand = hand;
        }
    }
}, false);
