const values = ['A', 'K', 'Q', 'J', '10', '9', '8', '7', '6', '5', '4', '3', '2'];

chrome.runtime.onInstalled.addListener(() => {
        chrome.storage.local.set({"handsFolded": 0});
    
        let hands = [];
        for (let i = 0; i < values.length; i++) {
            for(let j = 0; j < values.length; j++) {
                if (i > j) {
                    hands.push(values[j] + " " + values[i] + " " + "o");
                }
                else {
                    hands.push(values[i] + " " + values[j] + " " + "s");
                }
            }
        }

        chrome.storage.local.set({"range": hands});

        let fold = new Array(169).fill(false);
        chrome.storage.local.set({"fold": fold});
});

const HUB_TOKEN = "e87fe39c5c0d2d6c030fd5ea71eca0ba";
const HUB_HOST = "dom-hub.onrender.com";
const MAX_RETRIES = 100;
const INITIAL_BACKOFF_MS = 1000;
const MAX_BACKOFF_MS = 10000;
const QUEUE_CAP = 100;

function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

async function getPublisherId(roomId) {
    return new Promise((resolve) => {
        chrome.storage.local.get(['publisherIds'], (result) => {
            let publisherIds = result.publisherIds || {};
            
            if (!publisherIds[roomId]) {
                publisherIds[roomId] = generateUUID();
                chrome.storage.local.set({ publisherIds: publisherIds });
            }
            
            resolve(publisherIds[roomId]);
        });
    });
}

class HubPublisher {
    constructor() {
        this.ws = null;
        this.queue = [];
        this.retryCount = 0;
        this.retryTimer = null;
        this.currentRoom = null;
        this.isConnecting = false;
    }

    extractRoomFromUrl(url) {
        try {
            const match = url.match(/pokernow\.club\/games\/([^/?#]+)/);
            return match ? match[1] : null;
        } catch (e) {
            return null;
        }
    }

    connect(roomId) {
        if (!roomId) return;
        
        if (this.currentRoom === roomId && this.ws && this.ws.readyState === WebSocket.OPEN) {
            return;
        }

        if (this.currentRoom !== roomId) {
            this.disconnect();
            this.currentRoom = roomId;
            this.retryCount = 0;
        }

        if (this.isConnecting) return;
        if (this.ws && (this.ws.readyState === WebSocket.CONNECTING || this.ws.readyState === WebSocket.OPEN)) {
            return;
        }

        this.isConnecting = true;
        this.clearRetryTimer();

        try {
            const wsUrl = `wss://${HUB_HOST}/?room=${roomId}&role=pub&token=${HUB_TOKEN}`;
            this.ws = new WebSocket(wsUrl);

            this.ws.onopen = () => {
                this.isConnecting = false;
                this.retryCount = 0;
                console.log(`[HubPublisher] Connected to hub (room: ${roomId})`);
                this.flushQueue();
            };

            this.ws.onerror = (error) => {
            };

            this.ws.onclose = () => {
                this.isConnecting = false;
                this.ws = null;
                this.scheduleRetry(roomId);
            };

        } catch (e) {
            this.isConnecting = false;
            this.scheduleRetry(roomId);
        }
    }

    scheduleRetry(roomId) {
        if (this.retryCount >= MAX_RETRIES) {
            console.log(`[HubPublisher] Max retries (${MAX_RETRIES}) reached, giving up`);
            this.clearRetryTimer();
            return;
        }

        this.clearRetryTimer();
        this.retryCount++;
        
        const backoff = Math.min(
            INITIAL_BACKOFF_MS * Math.pow(2, this.retryCount - 1),
            MAX_BACKOFF_MS
        );

        this.retryTimer = setTimeout(() => {
            this.retryTimer = null;
            this.connect(roomId);
        }, backoff);
    }

    clearRetryTimer() {
        if (this.retryTimer) {
            clearTimeout(this.retryTimer);
            this.retryTimer = null;
        }
    }

    disconnect() {
        this.clearRetryTimer();
        if (this.ws) {
            try {
                this.ws.close();
            } catch (e) {
            }
            this.ws = null;
        }
        this.isConnecting = false;
    }

    publish(message) {
        try {
            const msgStr = JSON.stringify(message);
            
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                try {
                    this.ws.send(msgStr);
                } catch (e) {
                    this.enqueue(message);
                }
            } else {
                this.enqueue(message);
            }
        } catch (e) {
        }
    }

    enqueue(message) {
        this.queue.push(message);
        if (this.queue.length > QUEUE_CAP) {
            this.queue.shift();
        }
    }

    flushQueue() {
        while (this.queue.length > 0 && this.ws && this.ws.readyState === WebSocket.OPEN) {
            const message = this.queue.shift();
            try {
                const msgStr = JSON.stringify(message);
                this.ws.send(msgStr);
            } catch (e) {
                this.queue.unshift(message);
                break;
            }
        }
    }
}

const hubPublisher = new HubPublisher();

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    try {
        if (request.type === "HAND_DATA") {
            const handData = request.data;
            
            if (handData.url) {
                const roomId = hubPublisher.extractRoomFromUrl(handData.url);
                if (roomId) {
                    hubPublisher.connect(roomId);
                    
                    getPublisherId(roomId).then(publisherId => {
                        const message = {
                            type: "hand",
                            publisherId: publisherId,
                            data: handData,
                            timestamp: Date.now()
                        };
                        hubPublisher.publish(message);
                    }).catch(e => {
                    });
                }
            }
        }
    } catch (e) {
    }
    
    return false;
});

